/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package votancion;

/**
 *
 * @author 301
 */
public class Votancion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

System.out.println("Por favor introduzca la operacion"
+" que desea realizar");

Menu menu= new Menu();

    menu.menu();
        // TODO code application logic here
    }
    
}
