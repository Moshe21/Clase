/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package votancion;

import java.util.Scanner;

/**
 *
 * @author 301
 */
public class Menu{

    

String lugardeVotacion ="";
    private Scanner input= new Scanner(System.in);
    public void menu(){
  

System.out.println("--Bienvenido"
 + "por favor selecion su opcion--");
System.out.println(
    "Nuestro menu:  \n"
 + "1) Consultar punto de votacion \n"
 + "2) Consultar puntos de votacion con horario \n"
 + "extemdido \n");
    

int selection = input.nextInt();

        switch (selection){
        case 1:
           ConsultarPuntoVotacion();
        System.out.println("--1111111--");
        break;

        case 2:
            horarioVotacion();
        System.out.println("-222222222--");
        break;
         }

    }   

    void ConsultarPuntoVotacion(){
    
    System.out.println("por favor introduzca"
 + "su cedula:");

String cedula="";
Scanner entradaEscaner= new Scanner(System.in);

cedula=entradaEscaner.nextLine();

System.out.println("el numero de identidad"
 +"ques usted ha ingresado es : \""+cedula+"\"");

PuntoVotacion lugarsitiodeVotacion = new PuntoVotacion();


//llaa r
lugardeVotacion =  lugarsitiodeVotacion.sitiovotacion(cedula);


System.out.println("lugar de votacion es lugardeVotacion" +lugardeVotacion);


    }
void horarioVotacion(){

    System.out.println("HORARIO DE VOTACION SON 9 AM A 6PM");
}

}
    

