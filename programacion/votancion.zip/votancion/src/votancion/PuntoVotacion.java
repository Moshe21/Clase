/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package votancion;

import java.util.Scanner;

 /*
 * @author 301
 */

public class PuntoVotacion{

String puntodeVotacion;

String sitiovotacion(String cedula){

        if (cedula.startsWith("1")){

puntodeVotacion="el salitre";
        }else{


puntodeVotacion="Colferias";


        }
     return puntodeVotacion; 
    }
}