/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package moshe_sitp;

/**
 *
 * @author 301
 */
public class Punto_paradas {
    
String Punto_paradas;

String lugar_sitio_de_paradas(String ruta){

        if (ruta.startsWith("G42")){

Punto_paradas="el CAN";
        }else{


Punto_paradas="Heros";


        }
     return Punto_paradas; 
    }

}

