/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package moshe_sitp;

/**
 *
 * @author 301
 */
public class menu_1 {
    
String lugar_de_parada="";
    private Scanner input= new Scanner(System.in);
    public void menu_1(){
  

System.out.println("--Bienvenido Nuestro de alta confianza  \n por favor selecion su  requerimientos--");
System.out.println(
    "Nuestro menu:  \n"
 + "1) Digite la ruta de bus sobre la que desea conocer las paradas\n"
 + "2) Conocer rutas que funcionan en feriados \n"
 + "extemdido \n");
    

int selection = input.nextInt();

        switch (selection){
        case 1:
           Conoce_parada();
        System.out.println("--conocer las paradas--");
        break;

        case 2:
            Conocer_rutas();
        System.out.println("-Conocer rutas--");
        break;
         }

    }   

    void Conoce_parada(){
    
    System.out.println("por favor introduzca"
 + "su ruta:");

String ruta="";
Scanner entradaEscaner= new Scanner(System.in);

ruta=entradaEscaner.nextLine();

System.out.println("el numero de identidad"
 +"ques usted ha ingresado es : \""+ruta+"\"");

Punto_paradas lugar_sitio_de_paradas= new Punto_paradas();


//llaa r
Punto_paradas =  lugar_sitio_de_paradas.Punto_paradas(ruta);


System.out.println("lugar de votacion es lugardeVotacion" +Punto_paradas);


    }
void horarioVotacion(){

    System.out.println("HORARIO DE RUTA G42 SON L-V 9 AM A 6PM S 9 AM A 2PM");
    System.out.println("HORARIO DE RUTA K80 SON L-V 7 AM A 5 PM S 7 AM A 12 PM");
    
}

    private void Conocer_rutas() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
    
