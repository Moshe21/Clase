/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package moshe_sitp;

/**
 *
 * @author 301
 */
public class Moshe_Sitp {


 public static void main(String[] args) {

System.out.println("Por favor introduzca la operacion"
+" que desea realizar");

Menu_1 menu_1= new Menu_1();

    menu_1.menu();
        // TODO code application logic here
    }
    
}
