document.addEventListener('DOMContentLoaded', function() {
    // Navegación suave
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Animaciones al hacer scroll
    const animateOnScroll = function() {
        const elements = document.querySelectorAll('.module-card, .feature, .activity-item');
        
        elements.forEach(element => {
            const elementPosition = element.getBoundingClientRect().top;
            const screenPosition = window.innerHeight;
            
            if(elementPosition < screenPosition) {
                element.classList.add('animate-in');
            }
        });
    };

    // Inicializar animaciones
    document.querySelectorAll('.module-card, .feature, .activity-item').forEach(element => {
        element.classList.add('fade-up');
    });

    // Eventos de scroll
    window.addEventListener('scroll', animateOnScroll);
    animateOnScroll(); // Verificación inicial

    // Manejo de módulos interactivos
    document.querySelectorAll('.module-card').forEach(module => {
        module.addEventListener('click', function(e) {
            if (!e.target.classList.contains('btn')) {
                const link = this.querySelector('.btn');
                if (link) {
                    link.click();
                }
            }
        });
    });

    // Sistema de progreso
    const updateProgress = function() {
        const progressBars = document.querySelectorAll('.progress-bar');
        progressBars.forEach(bar => {
            const progress = parseInt(bar.getAttribute('data-progress'));
            bar.style.width = `${progress}%`;
        });
    };

    // Inicializar barras de progreso
    updateProgress();

    // Manejo de casos de uso interactivos
    document.querySelectorAll('.use-case-interactive').forEach(useCase => {
        useCase.addEventListener('click', function() {
            this.classList.toggle('expanded');
        });
    });

    // Validación de formularios
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Validación básica
            let isValid = true;
            const requiredFields = form.querySelectorAll('[required]');
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    isValid = false;
                    field.classList.add('error');
                } else {
                    field.classList.remove('error');
                }
            });

            if (isValid) {
                // Aquí iría la lógica de envío del formulario
                console.log('Formulario válido, enviando...');
            }
        });
    });
});

// Estilos CSS dinámicos
const styleSheet = document.createElement('style');
styleSheet.textContent = `
    .fade-up {
        opacity: 0;
        transform: translateY(20px);
        transition: all 0.6s ease-out;
    }

    .animate-in {
        opacity: 1;
        transform: translateY(0);
    }

    .progress-bar {
        height: 4px;
        background: var(--primary);
        transition: width 0.4s ease;
    }

    .use-case-interactive {
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .use-case-interactive.expanded {
        transform: scale(1.02);
    }

    .error {
        border-color: #ef4444 !important;
    }
`;
document.head.appendChild(styleSheet);
